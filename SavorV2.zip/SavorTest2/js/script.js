//Imports
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-app.js";
import { getDatabase, ref, set, get, } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";

{
//Consts and Vars

const firebaseConfig = {
  databaseURL: "https://savordatabase-default-rtdb.firebaseio.com"
};
const app = initializeApp(firebaseConfig);
const savorDB = getDatabase(app);

//Page Change Functions

window.createAcc = function() {
  window.location.href = "../html/create_acc.html";
}

window.forgotAcc = function(){
  window.location.href = "../html/forgotAccount.html";
}

window.handleLogin = function(){
  window.location.href = "../html/login.html";
}


//Search Function for Search Bar
window.searchRestaurants = function() {
      const query = document.getElementById("searchInput").value.trim();
      if (query) {
        // Open Google Maps with nearby search results
        const encodedQuery = encodeURIComponent(query + " restaurants near me");
        window.open(`https://www.google.com/maps/search/${encodedQuery}`, "_blank");
      } else {
        alert("Please enter a food type or restaurant name.");
      }
    }


//Login Function for Login Button 
window.submitLogin = function() {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  if (!username || !password) {
    alert('Please enter both username and password.');
    return;
  }
  console.log ("Username:", username);
  console.log ("Password:", password);

  const passRef = ref(savorDB, `user/${username}/password`);

  //Fetch stored password from DB to compare with typed password
  get(passRef)
      .then(snapshot => {
        if (snapshot.exists()) {
          const storedPassword = snapshot.val();
          console.log('Stored password for', username, ':', storedPassword);
          // compare with the typed password
          if (storedPassword === password) {
            console.log('Passwords match — login OK');
            window.location.href = "../html/index2.html";
          } else {
            console.log('Passwords do not match');
            alert('Incorrect password');
          }
        } else {
          console.log('No user found with username:', username);
          alert('No such user');
        }
      })
      .catch(err => {
        console.error('Error reading password:', err);
      });
    } 

    //create account page script from gabriel 
window.createAccount = function () {
      const username = document.getElementById('username').value.trim();
      const password = document.getElementById('password').value.trim();
      const confirmPassword = document.getElementById('confirmPassword').value.trim();
      const accountType = document.getElementById('accountType').value;
      const email = document.getElementById('email').value.trim();
      const firstName = document.getElementById('firstName').value.trim();
      const lastName = document.getElementById('lastName').value.trim();
      const birthDate = document.getElementById('birthDate').value.trim();

      
      const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}$/;
      if (!emailPattern.test(email)) {
        alert("Please enter a valid email address (e.g., johndoe1234@gmail.com).");
        return;
      }

      
      if (password !== confirmPassword) {
        alert("Passwords do not match. Please re-enter them.");
        return;
      }

      if (!accountType) {
        alert("Please select an account type.");
        return;
      }

      //My Section 

      const userRef = ref(savorDB, `user/${username}`);

  set(userRef, { password, email, accountType, firstName, lastName, birthDate })
  .then(() => {
    alert(`User "${username}" created successfully!`);

    if (accountType === "user") {
      window.location.href = "../html/index2.html";
    } else {
      window.location.href = "../html/business_DB.html";
    }
  })
  .catch(err => {
    console.error("Error creating user:", err);
    alert("Failed to create user.");
  });

      
    }

//events
document.addEventListener('keydown', (event) => { 
    const currentPath = window.location.pathname;
    const currentFileName = currentPath.substring(currentPath.lastIndexOf('/') + 1);

    if (currentFileName === "login.html" && event.key === "Enter") {
        submitLogin();
    }
    else if(currentFileName === "index.html" && event.key === "Enter") {
        searchRestaurants();
    }
    else if(currentFileName === "create_acc.html" && event.key === "Enter") {
        createAccount();
    }
    else if(currentFileName === "index2.html" && event.key === "Enter") {
      //Need next function for index2.html
    }
    
    });

      

}
